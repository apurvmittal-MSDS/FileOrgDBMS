sqldbpwd = "changeme"
sqldbhostname = '34.105.28.78'
