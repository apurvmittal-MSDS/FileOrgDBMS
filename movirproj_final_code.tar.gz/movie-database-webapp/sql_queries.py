
def list_top_n_movies_by_gross_revenue(sql_sort, sql_limit):
    query = f"""
        SELECT 
          concat(title, ' (', year, ')') as movie,
        Distributor 'Production House',
        Budget,
        Worldwide_BOC 'Worldwide Gross',
        Concat(convert(user_rating, CHAR), "⭐") Ratings,
        CAST( CAST(Worldwide_BOC AS UNSIGNED) + (Budget/-1) AS SIGNED) 'PROFIT'
        FROM
        Movie
        ORDER BY 4 {sql_sort}
        LIMIT {sql_limit};""".upper()
    return query

def billion_dollar_movies(sql_sort, sql_limit):
    query = f"""
        SELECT
       concat(title, ' (', year, ')') as Movie,
       worldwide_boc as 'Worldwide Gross',
        CAST( CAST(Worldwide_BOC AS UNSIGNED) + (Budget/-1) AS SIGNED) 'PROFIT',
        Concat(convert(user_rating, CHAR), "⭐") Ratings
         FROM
        Movie
        where worldwide_boc > 1000000000
        ORDER BY worldwide_boc  {sql_sort}
        LIMIT {sql_limit};""".upper()
    return query


def list_of_movies_with_biggest_losses(sql_sort, sql_limit):
    query = f"""
        SELECT 
       concat(title, ' (', year, ')') as Movie,
       worldwide_boc as 'Worldwide Gross',
        CAST( CAST(Worldwide_BOC AS UNSIGNED) + (Budget/-1) AS SIGNED) 'PROFIT/LOSS',
        Concat(convert(user_rating, CHAR), "⭐") Ratings
         FROM
        Movie  
        ORDER BY 3 {sql_sort} 
        LIMIT {sql_limit};""".upper()
    return query;

def highest_rated_movies(sql_sort, sql_limit):
    query = f"""
          SELECT   
          concat(title, ' (', year, ')') as movie,
        Distributor 'Production House',
       worldwide_boc as 'Worldwide Gross',
        CAST( CAST(Worldwide_BOC AS UNSIGNED) + (Budget/-1) AS SIGNED) 'PROFIT',
        Concat(convert(user_rating, CHAR), "⭐") Ratings
        FROM
        Movie
        ORDER BY user_rating {sql_sort}
        LIMIT {sql_limit};""".upper()
    return query


def actor_know_for(name, sql_sort, sql_limit):
    query = f"""
          SELECT   concat(title, ' (', year, ')') as movie,
       worldwide_boc as 'Worldwide Gross',
        CAST( CAST(Worldwide_BOC AS UNSIGNED) + (Budget/-1) AS SIGNED) 'PROFIT',
        Concat(convert(user_rating, CHAR), "⭐") Ratings
         FROM
         movie M, cast_crew cc, CC_KNOWNFOR kf
    WHERE
   m.id= kf.Movie_ID
    and kf.CAST_CREW_ID = cc.id
    and upper(cc.name) = '{name}'
   ORDER BY year {sql_sort}
    LIMIT {sql_limit};
    """.upper()
    return query

