from flask import Flask, render_template, request
from forms import WriteYourOwnQuery, MinimumUserInput
from utils import get_chart,handle_custom_form, handle_minimum_user_input_form, handle_query, list_of_customizable_queries, query_string
import altair as alt
import pandas as pd
import json
from pathlib import Path


app = Flask(__name__)
app.secret_key = 'development_key'


@app.route('/', methods=['GET', 'POST'])
def index():
    form_write_your_own_query = WriteYourOwnQuery()
    form_customizable = MinimumUserInput()
    print("back to index")

    return render_template("index.html", form_write_your_own_query=form_write_your_own_query,
                           form_customizable=form_customizable)


@app.route('/writeyourownquery', methods=['GET', 'POST'])
def write_your_own_query():
    form_write_your_own_query = WriteYourOwnQuery()
    form_customizable = MinimumUserInput()
    if request.method == "POST":
        if form_write_your_own_query.validate_on_submit():
            sql_query = handle_custom_form(form_write_your_own_query)
            data,data_df = handle_query(sql_query)
            print(data)
            return render_template("index.html", data=data, form_write_your_own_query=form_write_your_own_query,
                                   form_customizable=form_customizable, graph=False)


@app.route('/customizable', methods=['GET', 'POST'])
def customizable():
    form_write_your_own_query = WriteYourOwnQuery()
    form_customizable = MinimumUserInput()
    if request.method == "POST" and form_customizable.validate_on_submit():
        sql_sort, sql_limit, sql_type, sql_string_value = handle_minimum_user_input_form(form_customizable)
        sql_query,chart_type = list_of_customizable_queries(sql_type, sql_sort, sql_limit, sql_string_value)
        data,data_df = handle_query(sql_query)
        string_q = query_string(sql_sort, sql_limit, sql_type, sql_string_value)

        #chart_json = open('chart.json').read()
        chart_json = get_chart(data_df,chart_type, sql_sort)
        #print(chart_json)
        return render_template("index.html", data=data, form_write_your_own_query=form_write_your_own_query,
                               form_customizable=form_customizable, string_q=string_q, chart=chart_json, graph=True)


if __name__ == '__main__':
    app.run(host='0.0.0.0')
